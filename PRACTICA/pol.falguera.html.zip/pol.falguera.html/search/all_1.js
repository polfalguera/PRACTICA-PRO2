var searchData=
[
  ['baja_5fusuario_5',['baja_usuario',['../class_usuarios.html#a07e28ebb22f8c41dc322b7be6cd1c807',1,'Usuarios']]]
];
