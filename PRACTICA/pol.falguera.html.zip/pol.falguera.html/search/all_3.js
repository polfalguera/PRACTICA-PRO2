var searchData=
[
  ['decrementar_5finscritos_25',['decrementar_inscritos',['../class_curso.html#abc349f4408860c340e68a403960a0e98',1,'Curso']]],
  ['decrementar_5fusuarios_5finscritos_26',['decrementar_usuarios_inscritos',['../class_cursos.html#a426cbdefc60db4a745d99bbfcbaa5529',1,'Cursos']]],
  ['desinscribir_5fusuario_5fcurso_27',['desinscribir_usuario_curso',['../class_usuario.html#a12fbfcea331bd5d2670cf5a0f2a2ae82',1,'Usuario']]]
];
