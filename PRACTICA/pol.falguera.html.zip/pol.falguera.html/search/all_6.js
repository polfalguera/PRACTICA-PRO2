var searchData=
[
  ['leer_5fcoleccion_5fproblemas_57',['leer_coleccion_problemas',['../class_problemas.html#a6d16937dea64409081e507065e17f2b1',1,'Problemas']]],
  ['leer_5fconjunto_5fcursos_58',['leer_conjunto_cursos',['../class_cursos.html#adcd9b10c30b41d1a4884184f9eb9aecf',1,'Cursos']]],
  ['leer_5fconjunto_5fsesiones_59',['leer_conjunto_sesiones',['../class_sesiones.html#a88fc086cf1b55ed711f78f143323ad22',1,'Sesiones']]],
  ['leer_5fconjunto_5fusuarios_60',['leer_conjunto_usuarios',['../class_usuarios.html#a2ea007ca9e24e599cf2294702f29d113',1,'Usuarios']]],
  ['leer_5fcurso_61',['leer_curso',['../class_curso.html#a56ba1a8fa89ca944b7a6bd21f97d06c6',1,'Curso']]],
  ['leer_5fproblemas_5fsesion_62',['leer_problemas_sesion',['../class_sesion.html#a01d27c95800c1dfdb88f6c9e20701c39',1,'Sesion']]],
  ['leer_5fsesion_63',['leer_sesion',['../class_sesion.html#a970d42fc3310a465b78b5a1549c30ec1',1,'Sesion']]],
  ['listar_5fcursos_64',['listar_cursos',['../class_cursos.html#a84a06aae82ea6b8694be628495edc44e',1,'Cursos']]],
  ['listar_5fidentificador_5fenvios_65',['listar_identificador_envios',['../class_problemas.html#a9acf13599085049d66b7099f36bfd122',1,'Problemas']]],
  ['listar_5fproblemas_66',['listar_problemas',['../class_problemas.html#a8c3ec08e7f02cc4ce8c2b5e9a3e19f4c',1,'Problemas']]],
  ['listar_5fsesiones_67',['listar_sesiones',['../class_sesiones.html#a946118243a41df8ef38d85c6b792d657',1,'Sesiones']]],
  ['listar_5fusuarios_68',['listar_usuarios',['../class_usuarios.html#aec9c5d893c8da2752a83f1ccefa40b00',1,'Usuarios']]]
];
