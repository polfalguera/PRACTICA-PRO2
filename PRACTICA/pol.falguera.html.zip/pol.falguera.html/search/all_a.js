var searchData=
[
  ['ratio_107',['ratio',['../struct_problema.html#acc3d2ce24418ad68650108de4b603d99',1,'Problema']]],
  ['resueltos_108',['resueltos',['../class_usuario.html#a5eb4dd810d42c4901a807c2ac9611fef',1,'Usuario']]]
];
