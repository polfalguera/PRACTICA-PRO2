var searchData=
[
  ['problema_128',['Problema',['../struct_problema.html',1,'']]],
  ['problemas_129',['Problemas',['../class_problemas.html',1,'']]]
];
