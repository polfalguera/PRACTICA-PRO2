var searchData=
[
  ['actualizar_5fenviables_149',['actualizar_enviables',['../class_usuario.html#ac861c8f3c3218a9ba355175a42505734',1,'Usuario']]],
  ['actualizar_5fratio_150',['actualizar_ratio',['../class_problemas.html#ac5ebeb4af82a613e8ef5506516546cf0',1,'Problemas']]],
  ['actualizar_5fresueltos_151',['actualizar_resueltos',['../class_usuario.html#af4654f1d2134af3e6e00c36b39f80be8',1,'Usuario']]],
  ['alta_5fusuario_152',['alta_usuario',['../class_usuarios.html#af5c88a949710ae4f23fbd653baeeb37b',1,'Usuarios']]],
  ['anadir_5fresuelto_153',['anadir_resuelto',['../class_problemas.html#aef3b18810d73f513411668a6c2e700bb',1,'Problemas']]]
];
