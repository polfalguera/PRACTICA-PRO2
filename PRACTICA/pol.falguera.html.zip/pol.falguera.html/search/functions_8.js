var searchData=
[
  ['nueva_5fsesion_214',['nueva_sesion',['../class_sesiones.html#a5f743432fcab3577f98a53e8096a9844',1,'Sesiones']]],
  ['nuevo_5fcurso_215',['nuevo_curso',['../class_cursos.html#a78452941945e62a07a717cb5188332fd',1,'Cursos']]],
  ['nuevo_5fproblema_216',['nuevo_problema',['../class_problemas.html#a1cd32a5ef40dd4709ed8a509dce1271a',1,'Problemas']]],
  ['numero_5fcursos_217',['numero_cursos',['../class_cursos.html#acb249ba8a4ded144fba197d8dc06dfef',1,'Cursos']]],
  ['numero_5finscritos_5fcurso_218',['numero_inscritos_curso',['../class_cursos.html#a2e2b722805adbbf5dada20e94aec024c',1,'Cursos']]],
  ['numero_5fproblemas_219',['numero_problemas',['../class_problemas.html#a85760dffc679b07de2db9bda4ec2ff80',1,'Problemas']]],
  ['numero_5fproblemas_5fenviables_220',['numero_problemas_enviables',['../class_usuario.html#a10b1a8312c399d826fe58ded1dea5658',1,'Usuario']]],
  ['numero_5fproblemas_5fsesion_221',['numero_problemas_sesion',['../class_sesiones.html#a2b16066bec1058ec9c0d2fa0a1e03743',1,'Sesiones']]],
  ['numero_5fsesiones_222',['numero_sesiones',['../class_sesiones.html#a3ac4b17c9e49aaa2e6f893abf59ee959',1,'Sesiones']]],
  ['numero_5ftotal_5fenvios_5fp_223',['numero_total_envios_p',['../class_problemas.html#aa58e4dfaa6e81717408ce7b14d3d4fee',1,'Problemas']]],
  ['numero_5fusuarios_224',['numero_usuarios',['../class_usuarios.html#a25b22bf6c2ed83d6136a8d6e80745b44',1,'Usuarios']]],
  ['numero_5fusuarios_5finscritos_225',['numero_usuarios_inscritos',['../class_curso.html#a9b12a34058fcb3c1dd5a63aa59484aa5',1,'Curso']]]
];
