var searchData=
[
  ['problema_5fiesimo_5fsesion_226',['problema_iesimo_sesion',['../class_sesiones.html#a75baf2c7f1251f77021751ed8164d61c',1,'Sesiones']]],
  ['problemas_227',['Problemas',['../class_problemas.html#ae587a6825117a5103b50f544a7415c0c',1,'Problemas']]],
  ['problemas_5fenviables_228',['problemas_enviables',['../class_usuario.html#a79c8b5d178c8cfe7604210dc38d41fa1',1,'Usuario']]],
  ['problemas_5fenviables_5fusuario_229',['problemas_enviables_usuario',['../class_usuarios.html#a6ce2b5e87faed1e30535aa2a8a8e2de1',1,'Usuarios']]],
  ['problemas_5fresueltos_230',['problemas_resueltos',['../class_usuario.html#a11b719ee95e8089a4f34c172c81f2a5b',1,'Usuario']]],
  ['problemas_5fresueltos_5fusuario_231',['problemas_resueltos_usuario',['../class_usuarios.html#ad129a0c224f29338f0ccdd557ed6b786',1,'Usuarios']]]
];
