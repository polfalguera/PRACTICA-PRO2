var searchData=
[
  ['usuario_238',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario']]],
  ['usuarios_239',['Usuarios',['../class_usuarios.html#a90a1868e60e0914555701ae554aa9e87',1,'Usuarios']]]
];
