var searchData=
[
  ['práctica_20pro2_20_2d_20programa_20usando_20un_20diseño_20modular_3a_20plataforma_20_22evaluator_22_2e_259',['Práctica PRO2 - Programa usando un diseño modular: Plataforma &quot;EVALUATOR&quot;.',['../index.html',1,'']]]
];
