var searchData=
[
  ['enviables_244',['enviables',['../class_usuario.html#acaa851265a0f972b1bc28ee3801141b6',1,'Usuario']]]
];
