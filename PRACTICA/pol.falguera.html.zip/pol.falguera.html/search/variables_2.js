var searchData=
[
  ['id_5fcurso_5finscrito_245',['id_curso_inscrito',['../class_usuario.html#a7be56afc931ead7a75f86066996b7c65',1,'Usuario']]],
  ['id_5fproblemas_246',['id_problemas',['../class_sesion.html#a0229630ec3b5b9f25138c7c01e6c8719',1,'Sesion']]]
];
