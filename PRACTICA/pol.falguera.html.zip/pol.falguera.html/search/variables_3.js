var searchData=
[
  ['num_5ftotal_5fcorrectos_247',['num_total_correctos',['../struct_problema.html#af24d16202e8c86d27511c536bb28afa1',1,'Problema']]],
  ['num_5ftotal_5fenvios_248',['num_total_envios',['../struct_problema.html#ab5730d9976e8cbb8fb219b0b1316e959',1,'Problema']]],
  ['num_5fusuarios_5fcompletado_249',['num_usuarios_completado',['../class_curso.html#a1d0468c1a842f6b470d6ab06f06cf088',1,'Curso']]],
  ['num_5fusuarios_5finscritos_250',['num_usuarios_inscritos',['../class_curso.html#a622e50c0929b59f157b08eab1b88a681',1,'Curso']]],
  ['numero_5fproblemas_251',['numero_problemas',['../class_sesion.html#ac1d7a01973b833526f556d29922a47b2',1,'Sesion']]],
  ['numero_5fproblemas_5fintentados_252',['numero_problemas_intentados',['../class_usuario.html#a6546d89313419083a6c522900643e2d0',1,'Usuario']]],
  ['numero_5ftotal_5fenvios_253',['numero_total_envios',['../class_usuario.html#a7fdecf647e249b236976e6463860b125',1,'Usuario']]]
];
