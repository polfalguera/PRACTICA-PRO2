var searchData=
[
  ['problemas_5fsesion_254',['problemas_sesion',['../class_sesion.html#a30b18411d7436ba7006e6193628c87ae',1,'Sesion']]],
  ['problemas_5fsesiones_5fcurso_255',['problemas_sesiones_curso',['../class_curso.html#a564974700bfa94987ad6c5082084cf5c',1,'Curso']]]
];
