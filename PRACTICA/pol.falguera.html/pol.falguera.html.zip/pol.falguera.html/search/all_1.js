var searchData=
[
  ['baja_5fusuario_1',['baja_usuario',['../class_usuarios.html#a11e75ce29066b53e84731315ef476312',1,'Usuarios']]]
];
