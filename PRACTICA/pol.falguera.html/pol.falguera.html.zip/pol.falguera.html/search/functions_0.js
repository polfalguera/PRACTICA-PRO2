var searchData=
[
  ['alta_5fusuario_76',['alta_usuario',['../class_usuarios.html#a2a5a9dfe49ee726fcb8225cc865cadac',1,'Usuarios']]]
];
