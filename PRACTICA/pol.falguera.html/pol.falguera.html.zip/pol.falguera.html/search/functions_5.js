var searchData=
[
  ['incrementar_5fusuarios_5fcompletado_96',['incrementar_usuarios_completado',['../class_cursos.html#a3ce8af0e0132939cf6f51a4321d58d7f',1,'Cursos']]],
  ['incrementar_5fusuarios_5finscritos_97',['incrementar_usuarios_inscritos',['../class_cursos.html#a8e05dcf1247f0123619b711a68ca4a66',1,'Cursos']]],
  ['inscribir_5fcurso_98',['inscribir_curso',['../class_usuarios.html#ae238ea7e94249359946672e219b4062f',1,'Usuarios']]]
];
