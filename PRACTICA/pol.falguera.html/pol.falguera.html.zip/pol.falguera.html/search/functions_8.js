var searchData=
[
  ['nueva_5fsesion_112',['nueva_sesion',['../class_sesiones.html#a9a08619cdbf3cdc21b7be343c2f05ce4',1,'Sesiones']]],
  ['nuevo_5fcurso_113',['nuevo_curso',['../class_cursos.html#a78452941945e62a07a717cb5188332fd',1,'Cursos']]],
  ['nuevo_5fproblema_114',['nuevo_problema',['../class_problemas.html#a1cebce2784b951482651d299be50d8b3',1,'Problemas']]],
  ['numero_5fcursos_115',['numero_cursos',['../class_cursos.html#acb249ba8a4ded144fba197d8dc06dfef',1,'Cursos']]],
  ['numero_5fproblemas_116',['numero_problemas',['../class_problemas.html#a730f2cf3c1f2218fc565994fd8d6c48d',1,'Problemas']]],
  ['numero_5fsesiones_117',['numero_sesiones',['../class_sesiones.html#aa2f82c9a02e16d6eee4ba571b8df2669',1,'Sesiones']]],
  ['numero_5fusuarios_118',['numero_usuarios',['../class_usuarios.html#a25b22bf6c2ed83d6136a8d6e80745b44',1,'Usuarios']]]
];
