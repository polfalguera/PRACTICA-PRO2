var searchData=
[
  ['problemas_119',['Problemas',['../class_problemas.html#ae587a6825117a5103b50f544a7415c0c',1,'Problemas']]],
  ['problemas_5fenviables_120',['problemas_enviables',['../class_usuario.html#a79c8b5d178c8cfe7604210dc38d41fa1',1,'Usuario']]],
  ['problemas_5fresueltos_121',['problemas_resueltos',['../class_usuario.html#a11b719ee95e8089a4f34c172c81f2a5b',1,'Usuario']]]
];
