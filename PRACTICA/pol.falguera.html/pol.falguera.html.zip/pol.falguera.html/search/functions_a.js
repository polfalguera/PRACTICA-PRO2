var searchData=
[
  ['repeticion_5fejercicios_122',['repeticion_ejercicios',['../class_curso.html#a3b3a7f6bba7a12e43cbecfa0208c17f2',1,'Curso']]]
];
