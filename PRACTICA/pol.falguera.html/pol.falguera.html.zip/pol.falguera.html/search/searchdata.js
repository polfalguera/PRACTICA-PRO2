var indexSectionsWithContent =
{
  0: "abcdeilmnprsu",
  1: "cpsu",
  2: "cpsu",
  3: "abcdeilmnprsu",
  4: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Páginas"
};

